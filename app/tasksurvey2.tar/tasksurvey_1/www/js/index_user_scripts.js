(function()
{
 "use strict";
 /*
   hook up event handlers 
 */
 function register_event_handlers()
 {
    
    
 }
 $(document).ready(register_event_handlers);
})();
